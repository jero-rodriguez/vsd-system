import VsDItemBaseModel from "./base-item-model.mjs";

export default class VsDFeature extends VsDItemBaseModel {}
